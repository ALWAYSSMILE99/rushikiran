package com.cts.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class MsgDao {
	public static Connection getConnection(){
		Connection con=null;
	    try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=(Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
	public static String purchaseDetails(String cardnumber,int cvvnumber,String address)
	{
		boolean k=false;
		String xy=null;
		
		try{
			Connection con=MsgDao.getConnection();
			 Statement st=con.createStatement();
	            int x=0;
	            String y="ORD_";
	            ResultSet r=st.executeQuery("Select count(*) from cart");
	            if(r.next())
	            {
	            	//x=r.getInt(1)+y;
	            	 xy = (y + r.getInt(1)+0001);
	            }
	            else{
	            	xy= "ORD_0001";
	            }
			
			PreparedStatement ps=con.prepareStatement("insert into orderstatus values(?,?,?,?) ");
			ps.setString(1, xy);
			ps.setString(2,cardnumber );
			ps.setInt(3,cvvnumber);
			ps.setString(4, address );
			 int status=ps.executeUpdate();
			if(status>0){
				k=true;
			}
		System.out.println(xy);
			
		}catch(Exception ex){ex.printStackTrace();}
		return xy;
		
	}
}

	/*public static String order()
	{
	String z= "xy";
		try 
		{
			Connection con=MsgDao.getConnection();
			 Statement st=con.createStatement();
			 PreparedStatement p=con.prepareStatement("select orderid from orderstatus ;");
			 ResultSet rs=p.executeQuery();
			 if(rs.next())
			 {
				 z=rs.getString(1);
			 }
			 con.close();
		}catch(Exception ex){ex.printStackTrace();}
			return z;	
	}
	

}*/
