package com.cts.Dao;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NewDao {
      public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
   
   
   
    public static  boolean newDetails( String email,String newpassword){  
       
          boolean b=false;
        try{  
            Connection con=NewDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("update reg set password=? where emailId=? ");  
           ps.setString(2,email);
           ps.setString(1,newpassword);
         
            int rs=ps.executeUpdate();  
            if(rs>0){  
                  b=true;                 
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return b;  
    }



      }
