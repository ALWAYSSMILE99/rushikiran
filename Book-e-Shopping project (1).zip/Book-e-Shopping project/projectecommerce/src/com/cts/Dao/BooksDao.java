package com.cts.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


	public class BooksDao {
		public static Connection getConnection(){
			Connection con=null;
		    try{  
	            Class.forName("oracle.jdbc.driver.OracleDriver");  
	            con=(Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
	        }catch(Exception e){System.out.println(e);}  
	        return con;  
		}
		public static boolean bookDetails(String books){
			System.out.println(books+".............");
			
			boolean b=false;
			try{
				Connection con=BooksDao.getConnection();
				PreparedStatement ps=con.prepareStatement("select * from bookdetails where BookName=?");
				ps.setString(1,books);
				System.out.println(books);
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					b=true;
				}
				con.close();
			}catch(Exception ex){ex.printStackTrace();}
			return b;
		
		
		
	}
	}
