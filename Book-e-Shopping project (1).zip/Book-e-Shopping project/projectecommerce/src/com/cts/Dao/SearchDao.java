package com.cts.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cts.bean.CartBean;

public class SearchDao {
	int s1;
	int p;
	int s;
	
	
	public static Connection getConnection(){
		Connection con=null;
	    try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=(Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
	public   CartBean searchDetails(String check,Integer quantity){
		CartBean cb=null;
		boolean b=false;
		System.out.println(check);
		System.out.println(quantity);
		try{
			Connection con=SearchDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select quantity from bookdetails where BookName=?");
			ps.setString(1,check);
			ResultSet rs=ps.executeQuery();
		
			if(rs.next())
			{
				 p=rs.getInt(1);
				s1= p - quantity;
			
			}
			
			if(quantity<p){
				PreparedStatement ps2=con.prepareStatement("update bookdetails set quantity=? where BookName=?");
				ps2.setInt(1,s1);
				ps2.setString(2,check);
				int rs2=ps2.executeUpdate();
			
			
			if(rs2>0){
			cb=	cartDetails(check,quantity);
				b=true;
					
				}
			}
			else{
				System.out.println("quantity entered is greater than availability");
			}
			
			
			
		}catch(Exception ex){ex.printStackTrace();}
		return cb;
		
		
	}
	public CartBean cartDetails(String check,int quantity){
		
		String a1=null;
		String a2=null;
		float a3=0;
		String a4=null;
		String a5=null;
		CartBean bn=new CartBean();
		float mp=0;
		
		try{
			System.out.println(quantity+"*****^^^^^^^^^^^^^^^^^^*"+check);
			Connection con=SearchDao.getConnection();
			PreparedStatement ps3=con.prepareStatement("select BookID,BookName,price,Language,AuthorName from bookdetails where BookName=? ");
			ps3.setString(1,check);
			ResultSet rs=ps3.executeQuery();
			if(rs.next()){
				a1=rs.getString(1);
				a2=rs.getString(2);
				a3=rs.getFloat(3);
				a4=rs.getString(4);
				a5=rs.getString(5);
				
			}
			 Statement st=con.createStatement();
	            int x=0;
	            ResultSet r=st.executeQuery("Select count(*) from cart");
	            if(r.next())
	            {
	            	x=r.getInt(1)+1;
	            }
	            else{
	            	x=1;
	            }
	           System.out.println(x+"!!!!!!!!!");
	         mp=quantity*a3;
			
			PreparedStatement ps4=con.prepareStatement("insert into  cart values(?,?,?,?,?,?,?,?)");
			System.out.println("-----"+x+" "+a1+" "+a2+" "+a3+" "+a4+" "+a5+" "+quantity+" "+ mp+"---------");
			
			bn.setCatid(x);
			bn.setBookId(a1);
			bn.setBookname(a2);
			bn.setAuthorname(a5);
			bn.setLanguage(a4);
			bn.setSelectedquantity(quantity);
			bn.setPrice(a3);
			bn.setTotalprice(mp);
			
			
			ps4.setInt(1, x);
				ps4.setString(2,a1);
				
				ps4.setString(3,a2);
				System.out.println(a2+"  @@@@@@@@@@@");
				ps4.setString(4,a5);
				System.out.println(a3+"  @@@@@@@@@@@");
				ps4.setString(5,a4);
				System.out.println(a4+"  @@@@@@@@@@@");
				ps4.setInt(6,quantity);
				System.out.println(a5+"  @@@@@@@@@@@");
				ps4.setFloat(7,a3);
				ps4.setFloat(8,  mp);
				System.out.println("**********Hello" + a4+a3);
				
				int status5=ps4.executeUpdate();
				System.out.println("**********Hello" + a4);
				
				if(status5>0){
					
					System.out.println("Your cart details...");
					
				}
				
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		return bn;
	}
	
	}
	





