package com.cts.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class purchaseDao {
	float cost;
	float b;
	int slq;
	public static Connection getConnection(){
		Connection con=null;
	    try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=(Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e){System.out.println(e);}  
        return con;  }  
	public boolean purchasedetails(String bookName, int selectedquantity, int price, int subtotal) {
		try{
			Connection con=SearchDao.getConnection();
			PreparedStatement ps=con.prepareStatement("Select selectedquantity, price from cart where catid=?");
			int catid;
			//ps.setInt(1, catid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				b=rs.getFloat(3);
				slq=rs.getInt(2);
				cost = b*slq;
			}
			//ps.setFloat(2, x);
			
	
		
		}catch(Exception ex){
			ex.printStackTrace();
			}
		return false;
		
		

}
}
