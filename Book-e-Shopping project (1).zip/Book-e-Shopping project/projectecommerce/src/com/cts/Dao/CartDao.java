package com.cts.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.bean.CartBean;

public class CartDao {
	public static Connection getConnection(){
		Connection con=null;
	    try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=(Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
	}
	public static boolean save (CartBean b) {
		boolean status= false;  
	    try{  
	        Connection con=RegistrationDao.getConnection();  
	        PreparedStatement p=con.prepareStatement("select bookid, bookname, authorname, language, price, selectedquantity, totalprice from cart where bookname = ?");
	        p.setString(1,b.getBookId());  
	        p.setString(2, b.getBookname());
	        p.setString(3, b.getLanguage());
	        p.setString(4, b.getAuthorname());
	        p.setFloat(6, b.getPrice());
	        p.setInt(7, b.getSelectedquantity());
	        p.setFloat(8,  b.getTotalprice());
	        int rs=p.executeUpdate();  
            if(rs>0){  
                  status=true;                 
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }
	  public static int update(CartBean b){  
	        int status=0;  
	        try{  
	        	System.out.println("@@@@@@@@@@@@@@"+ b.getCatid());
	            Connection con=CartDao.getConnection();  
	            PreparedStatement s=con.prepareStatement(  
	                         "update cart set language=?, price=?, selectedquantity=?  where catid=?");  
	            s.setString(1,b.getLanguage());  
	            s.setFloat(2,b.getPrice());  
	            s.setInt(3, b.getSelectedquantity()); 
	            s.setInt(4, b.getCatid()) ;
	            status=s.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return status;  
	    }  
	    public static int delete(int bookid){  
	        int status=0;  
	        try{  
	            Connection con=CartDao.getConnection();  
	            PreparedStatement ps=con.prepareStatement("delete from cart where catid=?");  
	            ps.setInt(1,bookid);  
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return status;  
	    }  
	    public static CartBean getBookById(int catid){  
	        CartBean b=new CartBean();  
	          
	        try{  
	            Connection con=CartDao.getConnection();  
	            PreparedStatement ps=con.prepareStatement("select * from cart where catid=?");  
	            ps.setInt(1, catid);  
	            ResultSet rs=ps.executeQuery();  
	            if(rs.next()){  
	            	
	                b.setBookId(rs.getString(2));  
	                b.setBookname(rs.getString(3));  
	                 b.setAuthorname(rs.getString(4));  
	                b.setLanguage(rs.getString(5));
	                b.setSelectedquantity(rs.getInt(6));
	                b.setPrice(rs.getFloat(7));  
	                b.setTotalprice(rs.getFloat(8));
	             
	            }  
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return b;  
	    }  
	    public static List<CartBean> getAllBooks(String bname){  
	        List<CartBean> list=new ArrayList<CartBean>();  
	          
	        try{  
	            Connection con=CartDao.getConnection();  
	            PreparedStatement ps=con.prepareStatement("select * from cart where bookname=?");
	            ps.setString(1, bname);
	            ResultSet rs=ps.executeQuery();  
	            while(rs.next()){  
	                CartBean b=new CartBean(); 
	                b.setCatid(rs.getInt(1));
	                b.setBookId(rs.getString(2));  
	                b.setBookname(rs.getString(3));  
	                b.setLanguage(rs.getString(4));  
	                b.setAuthorname(rs.getString(5)); 
	                b.setSelectedquantity(rs.getInt(6)); 
	                b.setPrice(rs.getFloat(7));  
	                b.setTotalprice(rs.getFloat(8));
	                list.add(b);  
	            }  
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return list;  
	    }  
	}  


      

      
