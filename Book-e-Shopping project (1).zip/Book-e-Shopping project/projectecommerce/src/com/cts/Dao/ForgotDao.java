package com.cts.Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ForgotDao {
                public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
   
   
   
    public static  boolean forgotdetail(String emailId,String securityQuestion,String ans){  
       
          boolean b=false;
        try{  
            Connection con=ForgotDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from reg where emailId=? and securityquestion=? and ans=?");  
           ps.setString(1,emailId);
           ps.setString(2, securityQuestion);
           ps.setString(3, ans);
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                  b=true;                 
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return b;  
    }
}
