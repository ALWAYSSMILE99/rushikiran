package com.cts.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import com.cts.bean.RegistrationBean;
import java.sql.ResultSet;

public class RegistrationDao {
                public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password-1");  
        }catch(Exception e)
        {
               System.out.println(e);
        }  
        return con;  
    }  
   

public static int save(RegistrationBean e){  
    int status=0;  
    try{  
        Connection con=RegistrationDao.getConnection();  
        PreparedStatement ps=con.prepareStatement(  
 "insert into reg(firstName,lastName, age,gender,contact,emailid,password, securityquestion,ans)values (?,?,?,?,?,?,?,?,?)");  
        ps.setString(1,e.getFirstName());  
        ps.setString(2,e.getLastName());  
        ps.setInt(3,e.getAge());  
        ps.setString(4,e.getGender());  
        ps.setString(5,e.getContactNumber());
        ps.setString(6,e.getEmailid());
        ps.setString(7,e.getPassword());
        ps.setString(8,e.getSecurityQuestion());
        ps.setString(9,e.getAns());
     
        status=ps.executeUpdate(); 
        System.out.println(status);
        
          
        con.close();  
    }catch(Exception ex){ex.printStackTrace();}  
      
    return status; 
}  

}  
