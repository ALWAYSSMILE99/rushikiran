package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.Dao.BooksDao;
import com.cts.Dao.loginDao;


@WebServlet("/BooksServlet")
public class BooksServlet extends HttpServlet {
	
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String books=request.getParameter("search5");
		
		
		System.out.println(books+"*****");
		
		boolean status=BooksDao.bookDetails(books);
		if(status){
			out.println("<html><head><style>body{background-image:url('bookwall.jpg');");
					out.println("background-position: center;") ;
					out.println("background-repeat: no-repeat;" );
					out.println("background-size: cover; ");
					out.println("background-color:Blanched Almond;}"
							+ "</style></head><body><table>");
			out.println("<center><br><br><br><br><br><form action='./SearchServlet' method='post'>"
					+ "<input type='hidden' name='check' value="+books+">");
			out.println("<input type='checkbox' name='check1' checked>");
			out.println("<input type='text' name='quantity' required placeholder='Quantity' style='padding:5px;width:5%;'>  "+ books);
			out.println("<br><br><input type='submit' name='ok' value='ADDTOCART'></form></table></center></body></html>");

		}
		else{
			
			response.setContentType("text/html");  
			out.println("<script type=\"text/javascript\">");  
			out.println("alert('No such book available');");
			out.println("</script>");
			
			//out.println("<html><head></head><body onload=\"alert('No such book found!!!')\"></body></html>");
			//out.println("No such book available...");
			//response.sendRedirect("Index.html");
			//RequestDispatcher rd= request.getRequestDispatcher("Index.html");
	        //rd.forward(request,  response);
		}
		out.close();
	}

}
