package com.cts.controller;

import java.io.IOException;  
import java.io.PrintWriter;  
  






import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;

import com.cts.Dao.CartDao;
import com.cts.bean.CartBean;
@WebServlet("/Edit2Servlet")  
public class Edit2Servlet extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        
        int id=Integer.parseInt(request.getParameter("catid"));  System.out.println("update?????????????????????????"+id);
        String bid=request.getParameter("bookid");  
        String bookname=request.getParameter("bookname");  
        String language=request.getParameter("language");  
        String author=request.getParameter("author");  
        int selectedquantity = Integer.parseInt(request.getParameter("selectedquantity"));
        float price = Float.parseFloat(request.getParameter("totalprice"));
        float p=Float.parseFloat(request.getParameter("baseprice"));
		
          
        CartBean b=new CartBean(); 
        System.out.println(bookname + "********"+id+"        >>>>>>>>>>>>>>>>>>>>>>> "+selectedquantity);
        b.setCatid(id);
        b.setBookId(bid);
		 b.setBookname(bookname);
		 b.setLanguage(language);
		 b.setAuthorname(author);
		 b.setSelectedquantity(selectedquantity);
		 b.setPrice(p);
		 b.setTotalprice(p*selectedquantity);
		 HttpSession hs=request.getSession();
		 List<CartBean> list= null;//(List<CartBean>) hs.getAttribute("list");

		  if(list==null){
		    list =new ArrayList<>();
		  }
		  // Add the name & cost to List
		  list.add(b);

		  hs.setAttribute("list",list);
        int status=CartDao.update(b);  
        if(status>0){  
            response.sendRedirect("CartViewServlet");  
        }else{  
            out.println("Sorry! unable to update record");  
            RequestDispatcher rd= request.getRequestDispatcher("CartViewServlet.html");
	        rd.forward(request,  response);
        }  
          
        out.close();  
    }  
  
} 