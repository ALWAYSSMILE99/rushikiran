package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.RegistrationBean;
import com.cts.Dao.ForgotDao;


@WebServlet("/ForgotServlet")
public class ForgotServlet extends HttpServlet {
                
    
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                PrintWriter out=response.getWriter();  
                                String emailId=request.getParameter("emailid");
        
        String securityQuestion=request.getParameter("securityQuestion");
        String answer=request.getParameter("ans");
        System.out.println(emailId);
        System.out.println(securityQuestion);
        System.out.println(answer);
        
           boolean status=ForgotDao.forgotdetail(emailId,securityQuestion,answer);  
           System.out.println(status);
        if(status=true){ 
        	System.out.println(status);
        	
            out.print("<p>Please change your password!</p>");
            RequestDispatcher rd= request.getRequestDispatcher("Newpassword.html");
            rd.forward(request,  response); 
        }
        else
        {  
        	response.setContentType("text/html");  
			out.println("<script type=\"text/javascript\">");  
			out.println("alert('Invalid Credentials');");
			out.println("</script>");
			
            //out.println("Invalid Credentials"); 
            //RequestDispatcher rd= request.getRequestDispatcher("Forgot.html");
            //rd.forward(request,  response); 
        }  
          
        out.close();  
    }  
  
        
                }
