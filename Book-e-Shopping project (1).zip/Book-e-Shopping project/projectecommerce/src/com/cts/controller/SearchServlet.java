package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.Dao.SearchDao;
import com.cts.bean.CartBean;


@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	   PrintWriter out=response.getWriter();
    	   CartBean cb=null;
    	   String check=request.getParameter("check");
    	   String check1=request.getParameter("check1");
    	   System.out.println(check1);
   		Integer quantity =Integer.parseInt(request.getParameter("quantity"));
	    SearchDao ob=new SearchDao();
	    System.out.println("search");
	    if(check1.equals("on")){
            cb=ob.searchDetails(check, quantity);
            //System.out.println("***************************"+status);
		if(cb!=null){
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@###########");
			HttpSession hs=request.getSession();
			hs.setAttribute("bname", check);
			
			

			  List<CartBean> list= (List<CartBean>) hs.getAttribute("list");

			  if(list==null){
			    list =new ArrayList<>();
			  }
			  // Add the name & cost to List
			  list.add(cb);

			  hs.setAttribute("list",list);
			RequestDispatcher rd=request.getRequestDispatcher("/CartViewServlet");
			rd.forward(request,response);
		}
		else{
			response.setContentType("text/html");  
			out.println("<script type=\"text/javascript\">");  
			out.println("alert('quantity entered is greater than availability');");
			out.println("</script>");
			
		}
	    }
		out.close();
}
}
