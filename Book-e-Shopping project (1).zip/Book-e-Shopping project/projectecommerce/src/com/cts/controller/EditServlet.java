package com.cts.controller;

import java.io.IOException;  
import java.io.PrintWriter;  
  



import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  

import com.cts.Dao.CartDao;
import com.cts.bean.CartBean;
@WebServlet("/EditServlet")  
public class EditServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
           throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        out.println("<center><h1>Update Book</h1></center>");  
        String catid=request.getParameter("id");  
        int id=Integer.parseInt(catid);  
          System.out.println(id+" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        CartBean b=CartDao.getBookById(id);  
        out.println("<html><head><style>body{background-image:url('bookwall.jpg');");
		out.println("background-position: center;") ;
		out.println("background-repeat: no-repeat;" );
		out.println("background-size: cover; ");
		out.println("background-color:Blanched Almond;}"
				+ "</style></head><body><center><table>"); 
        out.print("<form action='Edit2Servlet' method='post'>");  
        out.print("<table>");  
        out.print("<tr><td></td><td><input type='hidden' name='catid' value="+id+" ></td></tr>"); 
        out.print("<tr><td></td><td><input type='hidden' name='bookid' value="+b.getBookId()+"></td></tr>");  
        out.print("<tr><td>Book Name:</td><td><input type='text' name='bookname' value= " +b.getBookname()+" readonly/></td></tr>");  
        out.print("<tr><td>Language:</td><td><input type='text' name='language' value="+b.getLanguage()+" readonly/></td></tr>");  
        out.print("<tr><td>Author:</td><td><input type='text' name='author' value= "+b.getAuthorname()+" readonly/></td></tr>");  
        out.print("<tr><td>Price:</td><td><input type='text' name='totalprice' value="+b.getPrice()+" /></td></tr>");  
        out.print("<tr><td>Selected Quantity:</td><td><input type='text' name='selectedquantity' value='"+b.getSelectedquantity()+"'/></td></tr>");  
        double p=b.getTotalprice()/b.getSelectedquantity();
        out.println("<tr><td></td><td><input type='hidden' name='baseprice' value="+p+" /></td></tr>");
        
        
        out.print("</td></tr>");  
        out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");  
        out.print("</table>");  
        out.print("</form></center>");  
        out.println("</body></html>");
          
        out.close();  
    }  
} 