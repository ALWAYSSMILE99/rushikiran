package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.Dao.ForgotDao;
import com.cts.Dao.NewDao;


@WebServlet("/NewServlet")
public class NewServlet extends HttpServlet {
                
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                
                                
                                PrintWriter out=response.getWriter();  
                                String email=request.getParameter("emailid");
                                String newpassword=request.getParameter("password");
        
                                System.out.println("************"+email);
        
        boolean status=NewDao.newDetails(email,newpassword);  
        if(status){  
            out.print("<p> Your password is changed Succesfully!</p>");
            out.print("<p> Please login here!</p>");
           request.getRequestDispatcher("login.html").include(request, response);  
        }else{  
        	response.setContentType("text/html");  
			out.println("<script type=\"text/javascript\">");  
			out.println("alert('Invalid credentials');");
			out.println("</script>");
			
            //out.println("Invalid Credentials");
            //RequestDispatcher rd= request.getRequestDispatcher("Forgot.html");
            //rd.forward(request,  response); 
        }  
          
        out.close();  
    }  
  
                                
}
