package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.bean.RegistrationBean;
import com.cts.Dao.RegistrationDao;


@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
                                
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                
                                                          
                        PrintWriter out=response.getWriter();  
                        String fname=request.getParameter("firstName"); 
                        String lname=request.getParameter("lastName"); 
                        Integer Age = Integer.parseInt(request.getParameter("age"));
                        String gender=request.getParameter("gender");
                        String contactNumber =request.getParameter("contact");
                        String email=request.getParameter("emailid");
                        String password=request.getParameter("password");
                        String securityquestion=request.getParameter("securityQuestion");
                        String answer=request.getParameter("ans");
                        System.out.println(Age+fname+lname+gender+contactNumber+email+" "+password+securityquestion+answer);
                       
                        RegistrationBean e=new RegistrationBean();  
                        e.setFirstName(fname); 
                        e.setLastName(lname);
                        e.setAge(Age);
                        e.setGender(gender);
                        e.setContactNumber(contactNumber);
                        e.setEmail(email);
                        e.setPassword(password);
                        e.setSecurityQuestion(securityquestion);
                         e.setAns(answer);
                         System.out.println("****"+fname+"_____"+lname+"^^^^^"+Age+"#######");
                        int status=RegistrationDao.save(e);  
                        if(status>0){  
                            out.print("<p>Record saved successfully!</p>");  
                             
                            RequestDispatcher rd= request.getRequestDispatcher("login.html");
                            rd.forward(request,  response);
                        }
                        else
                        {  
                            out.println("Sorry! unable to save record... please try again"); 
                            RequestDispatcher rd= request.getRequestDispatcher("Registration.html");
                            rd.forward(request,  response); 
                        }  
                          
                          
                }
                
                
}
