package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.bean.CartBean;

@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();  
		HttpSession hs=request.getSession(false);
		response.setContentType("text/html");
		List<CartBean> list= (List<CartBean>) hs.getAttribute("list");
		double p=0.0;
		if(list!=null){
			 for(CartBean b:list){ 
				 p=p+b.getTotalprice();
				 out.println("<html><head><body><center>");
				 out.println("<h3>Purchase: "+b.getBookname()+"</h3>");
				 }
			 out.println("<html><head><style type='text/css'>body{background-image:url('bookwall.jpg');");
				out.println("background-position: center;") ;
				out.println("background-repeat: no-repeat;" );
				out.println("background-size: cover; ");
				out.println("background-color:Blanched Almond;}"
						+ "</style></head><body>");
			 out.println("<form action='./msgServlet' method='post'>");
			 out.print("<center><br><br><br><br><table>");  
			// out.println("<tr><td>Order ID:</td><td><input type='number' name='orderid' disabled/></td></tr>");
		        out.print("<tr><td>Total price:</td><td><input type='number' name='totalprice' value='"+p+"' disabled/></td></tr>"); 
		        out.print("<tr><td>Card number:</td><td><input type='text' name='cardnumber'required pattern=[0-9]{16} placeholder='xxxxxxxxxxxxxxxx' title='Card number'/></td></tr>");  
		        out.print("<tr><td>CVV number:</td><td><input type='password' name='cvv'required pattern=[0-9]{3} placeholder='cvv' title='cvv'/></td></tr>");  
		        out.print("<tr><td>Address:</td><td><input type='text' name='address' required/></td></tr>"); 
		        out.println("<tr><td><input type='submit' name='Buynow' value='Buy now'></td></tr>");
		        out.println("</table></center>");
		        out.println("</form>");
		        out.println("</body></html>");
		        
	}
		else
		{
			response.setContentType("text/html");  
			out.println("<script type=\"text/javascript\">");  
			out.println("alert('Your cart is empty!!!');");
			out.println("</script>");
		}
	}
}


