package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.Dao.MsgDao;
import com.cts.Dao.loginDao;

@WebServlet("/msgServlet")
public class msgServlet extends HttpServlet {
	
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	   PrintWriter out=response.getWriter();
    	   response.setContentType("text/html");
    	   String cardnumber=request.getParameter("cardnumber");
    	   Integer cvvnumber=Integer.parseInt(request.getParameter("cvv"));
    	   String address=request.getParameter("address");
    	   String status=MsgDao.purchaseDetails(cardnumber,cvvnumber,address);
    	   //String m=MsgDao.order();
    	   if(status!=null){
    		   
    		   out.println("<!DOCTYPE html><html><head><style>body{margin:0;background-image:url('bookwall.jpg');background-position: center; "
    		   +"background-repeat: no-repeat; background-size: cover; background-color:#000033; }"+
    		   ".nav{ width:100%; background:#000033; height:80px;  text-align: center; }"+
    		   "ul{list-style:none;padding:0;  margin:0;  position:absolute;}"+
    		   "ul li{ float:left; margin-top:20px;}  ul li a{ width:200px; color:white; display:block; text-decoration:none;"+
    		   "font-size:20px; text-align:center;  padding:10px; margin-right: 110px; border-radius:10px;font-family:century Ghotic;font-weight:bold;}"+
    		   "a:hover{ background:#669900;} form{ width:1000px; margin:auto; margin-top:30px;}"+
    		   ".search5{width:80%; padding:10px; font-size:20px;});</style></head><body><div class='nav'><ul><li><a href='Index.html'>HOME</a></li>"+
"<li><a href='About.html'>ABOUT</a></li><li><a href='login.html'>LOGOUT</a></li><li><a href='contact.html'>CONTACT</a></li>"+
"</ul></div><center> <br><br><br><br><h3 style='color:Green';>Order Placed Successfully</h3><h3 style='color:Green';>Order ID:"+status+"</h3>"+
"</center></body></html>");
    		   //RequestDispatcher rd= request.getRequestDispatcher("Order.html");
               //rd.include(request,  response); 
    	   }
	}

}
