package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.Dao.CartDao;
import com.cts.bean.CartBean;
@WebServlet("/CartViewServlet")  
public class CartViewServlet extends HttpServlet {
	
		protected void service(HttpServletRequest arg0, HttpServletResponse arg1)
				throws ServletException, IOException {
		System.out.println("SEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE");
		doGet(arg0, arg1);
		}
protected void doGet(HttpServletRequest request, HttpServletResponse response)   
        throws ServletException, IOException {  
 
 HttpSession hs=request.getSession(false);
//String s=(String)	hs.getAttribute("bname");
 PrintWriter out=response.getWriter();    
 out.println("<h1>Cart List</h1>"); 
 List<CartBean> list= (List<CartBean>) hs.getAttribute("list");
 //List<CartBean> list=CartDao.getAllBooks(s);  
 out.println("<html><head><style>body{background-image:url('bookwall.jpg');");
	out.println("background-position: center;") ;
	out.println("background-repeat: no-repeat;" );
	out.println("background-size: cover; ");
	out.println("background-color:Blanched Almond;}"
			+ "</style></head><body><table>");
  out.println("<form action='./OrderServlet' method='post'>"); 
 out.print("<table border='1' width='100%'");  
 out.print("<tr><th>CAT ID</th><th>Book Id</th><th>Book Name</th><th>Author</th><th>Language</th><th>Price</th><th>SelectedQuantity</th><th>Total price</th><th>Edit</th><th>Delete</th></tr>");
 if(list!=null){
 for(CartBean b:list){  
  out.print("<tr><td>"+b.getCatid()+"</td><td>"+b.getBookId()+"</td><td>"+b.getBookname()+"</td><td>"+b.getAuthorname()+"</td><td>"+b.getLanguage()+"</td><td>"+b.getPrice()+"</td><td>"+b.getSelectedquantity()+"</td><td>"+b.getTotalprice()+"</td><td><a href='EditServlet?id="+b.getCatid()+"'>edit</a></td><td><a href='deleteServlet?id="+b.getCatid()+"'>delete</a></td></tr>");  
 }
 }  
 out.print("</table>");  
 out.println("<center><br><tr><td colspan='2'><input type='submit' value='Purchase'></td></tr></center>");
 out.println("</form>"); 
 out.println("<center><br><br><tr><td colspan='2'><a href='Index.html'>Continue Shopping</td></tr></center>");
 System.out.println("**************");
 out.close();
 
}  
}  