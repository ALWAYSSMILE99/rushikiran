


package com.cts.bean;

import java.util.Date;

public class RegistrationBean {
private String firstName,lastName,emailid,password;
private int age;
private String gender;
private String contactNumber;
private String securityQuestion;
private String ans;
private String deliAddress;

public String getDeliAddress() {
       return deliAddress;
}
public void setDeliAddress(String deliAddress) {
       this.deliAddress = deliAddress;
}
public String getSecurityQuestion() {
      return securityQuestion;
}
public String getFirstName() {
       return firstName;
}
public void setFirstName(String firstName) {
       this.firstName = firstName;
}
public String getLastName() {
       return lastName;
}
public void setLastName(String lastName) {
       this.lastName = lastName;
}
public String getEmailid() {
       return emailid;
}
public void setEmail(String email) {
       this.emailid = email;
}
public String getPassword() {
       return password;
}
public void setPassword(String password) {
       this.password = password;
}

public int getAge() {
       return age;
}
public void setAge(int age) {
       this.age = age;
}
public String getGender() {
       return gender;
}
public void setGender(String gender) {
       this.gender = gender;
}


public String getContactNumber() {
       return contactNumber;
}
public void setContactNumber(String contactNumber) {
       this.contactNumber = contactNumber;
}
public String getAns() {
       return ans;
}
public void setAns(String ans) {
       this.ans = ans;
}
public void setSecurityQuestion(String securityQuestion) {
       this.securityQuestion = securityQuestion;
}


}

